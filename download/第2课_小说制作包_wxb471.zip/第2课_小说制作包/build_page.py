# -*- coding: utf-8 -*-
"""把 Markdown 成果编译为单文件阅读版 11_阅读版.html（零外部依赖）。"""
import re, json, html, io, os

BASE = os.path.dirname(os.path.abspath(__file__))

def read(p):
    with open(os.path.join(BASE, p), encoding='utf-8') as f:
        return f.read()

def inline(t):
    t = html.escape(t, quote=False)
    t = re.sub(r'\*\*(.+?)\*\*', r'<strong>\1</strong>', t)
    t = re.sub(r'`(.+?)`', r'<code>\1</code>', t)
    return t

def md2html(md, drop_first_h1=False):
    lines = md.split('\n')
    out = []
    i = 0
    first_h1_dropped = False
    while i < len(lines):
        line = lines[i]
        s = line.rstrip()
        if not s.strip():
            i += 1
            continue
        if s.strip() == '---':
            out.append('<hr class="rule">')
            i += 1
            continue
        m = re.match(r'^(#{1,4})\s+(.*)$', s)
        if m:
            lv = len(m.group(1)); txt = inline(m.group(2).strip())
            if lv == 1 and drop_first_h1 and not first_h1_dropped:
                first_h1_dropped = True
                i += 1
                continue
            out.append('<h%d>%s</h%d>' % (lv, txt, lv))
            i += 1
            continue
        if s.lstrip().startswith('|'):
            block = []
            while i < len(lines) and lines[i].lstrip().startswith('|'):
                block.append(lines[i].strip())
                i += 1
            rows = []
            for r in block:
                cells = [c.strip() for c in r.strip('|').split('|')]
                rows.append(cells)
            if len(rows) >= 2 and re.match(r'^[\s:\-]+$', rows[1][0]):
                head = rows[0]; body = rows[2:]
            else:
                head = None; body = rows
            t = ['<div class="tbl"><table>']
            if head:
                t.append('<thead><tr>' + ''.join('<th>%s</th>' % inline(c) for c in head) + '</tr></thead>')
            t.append('<tbody>')
            for r in body:
                t.append('<tr>' + ''.join('<td>%s</td>' % inline(c) for c in r) + '</tr>')
            t.append('</tbody></table></div>')
            out.append(''.join(t))
            continue
        if s.lstrip().startswith('>'):
            block = []
            while i < len(lines) and lines[i].lstrip().startswith('>'):
                block.append(lines[i].lstrip()[1:].strip())
                i += 1
            out.append('<blockquote>%s</blockquote>' % '<br>'.join(inline(b) for b in block))
            continue
        if re.match(r'^\s*(?:[-*]|\d+\.)\s+', s):
            ordered = bool(re.match(r'^\s*\d+\.\s+', s))
            items = []
            while i < len(lines) and re.match(r'^\s*(?:[-*]|\d+\.)\s+', lines[i]):
                it = re.sub(r'^\s*(?:[-*]|\d+\.)\s+', '', lines[i]).strip()
                items.append('<li>%s</li>' % inline(it))
                i += 1
            out.append('<%s>%s</%s>' % ('ol' if ordered else 'ul', ''.join(items), 'ol' if ordered else 'ul'))
            continue
        # paragraph
        para = []
        while i < len(lines) and lines[i].strip() and not re.match(r'^(#{1,4}\s|\||>|---|\s*(?:[-*]|\d+\.)\s)', lines[i]):
            para.append(lines[i].strip())
            i += 1
        txt = '\n'.join(para)
        cls = ' class="dlg"' if re.fullmatch(r'「[^」]*」', txt.strip()) else ''
        out.append('<p%s>%s</p>' % (cls, inline(txt)))
    return '\n'.join(out)

# ---------- 正文：按章拆分 ----------
body_md = read('06_正文_三章.md')
parts = re.split(r'\n# (第[一二三]章[^\n]*)', body_md)
chapters = []
for i in range(1, len(parts), 2):
    title = parts[i].strip()
    chapters.append({'title': title, 'html': md2html(parts[i + 1])})
assert len(chapters) == 3, len(chapters)

setting_html = md2html(read('01_世界观设定集.md'), drop_first_h1=True)
style_html = md2html(read('00_风格基线.md'), drop_first_h1=True)

# CSV -> markdown 表（校对表用真实 CSV 渲染）
import csv
def csv2md(path):
    with open(os.path.join(BASE, path), encoding='utf-8') as f:
        rows = list(csv.reader(f))
    head = rows[0]
    lines = ['| ' + ' | '.join(head) + ' |', '| ' + ' | '.join(['---'] * len(head)) + ' |']
    for r in rows[1:]:
        lines.append('| ' + ' | '.join(c.replace('|', '/') for c in r) + ' |')
    return '\n'.join(lines)

audit_html = md2html(csv2md('07_连续性校对表.csv'))
sales_html = md2html(read('13_IP商业化与销售方案.md'), drop_first_h1=True)
notes_html = md2html(read('12_制作说明.md'), drop_first_h1=True) if os.path.exists(os.path.join(BASE, '12_制作说明.md')) else '<p>制作说明生成中。</p>'

# ---------- 索引 ----------
idx = json.load(open(os.path.join(BASE, '08_索引.json'), encoding='utf-8'))['items']
CATS = ['人物', '地点', '道具', '术语']

rows = []
for n, it in enumerate(idx):
    rows.append(
        '<tr id="idx-%d" class="idxrow"><td class="c-name">%s</td><td><span class="tag tag-%s">%s</span></td>'
        '<td class="c-ch">第 %d 章</td><td>%s</td><td class="c-rel">%s</td></tr>'
        % (n, html.escape(it['name']), it['category'], it['category'], it['first_chapter'],
           html.escape(it['gloss']), '、'.join(it['related']))
    )
appendix_table = (
    '<div class="tbl"><table class="idxtable"><thead><tr><th>名称</th><th>类别</th><th>首次出现</th>'
    '<th>释义</th><th>关联条目</th></tr></thead><tbody>%s</tbody></table></div>' % ''.join(rows)
)
counts = {c: len([i for i in idx if i['category'] == c]) for c in CATS}

nav = [('cover', '封面'), ('ch1', chapters[0]['title']), ('ch2', chapters[1]['title']),
       ('ch3', chapters[2]['title']), ('setting', '世界观设定集'), ('appendix', '设定附录 · 索引'),
       ('audit', '连续性校对表'), ('sales', 'IP 商业化与销售'), ('notes', '制作说明')]

nav_html = ''.join('<a class="navitem" data-t="%s" href="#%s"><span class="dot"></span>%s</a>'
                   % (k, k, html.escape(v)) for k, v in nav)

ch_blocks = []
for n, ch in enumerate(chapters, 1):
    ch_blocks.append('<section class="panel" id="ch%d"><div class="chapter">%s</div>%s</section>'
                     % (n, md2html('# ' + ch['title']).replace('<h1>', '<h1 class="chtitle">') + ch['html'],
                        '<div class="pager">%s%s</div>' % (
                            '<button class="pg" data-go="%s">← 上一章</button>' % (('ch%d' % (n - 1)) if n > 1 else 'cover'),
                            '<button class="pg" data-go="%s">下一章 →</button>' % (('ch%d' % (n + 1)) if n < 3 else 'setting'))))
CH = ''.join(ch_blocks)

page = """<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>账本城 · 三章短篇与设定集</title>
<meta name="description" content="课堂虚构作品《账本城》：三章短篇、世界观设定集、索引与连续性校对表。">
<style>
:root{
  --paper:#faf7f1; --paper2:#f3eee3; --ink:#1f2428; --ink2:#4a545c; --ink3:#8a9299;
  --line:#e2dacb; --blue:#4f6474; --blue-l:#e7edf1; --copper:#a6844f; --hit:#f6e7c8;
  --serif:"Songti SC","SimSun","Noto Serif SC",Georgia,serif;
  --sans:"PingFang SC","Microsoft YaHei","Hiragino Sans GB",system-ui,sans-serif;
}
*{box-sizing:border-box}
html{scroll-behavior:smooth}
body{margin:0;background:var(--paper);color:var(--ink);font-family:var(--serif);font-size:17px;line-height:1.95;-webkit-font-smoothing:antialiased}
#bar{position:fixed;top:0;left:0;height:2px;background:var(--copper);width:0;z-index:60;transition:width .15s}
.wrap{display:flex;min-height:100vh}
aside{width:276px;flex:0 0 276px;border-right:1px solid var(--line);background:var(--paper2);
  position:sticky;top:0;height:100vh;overflow-y:auto;padding:26px 20px 40px}
.brand{font-family:var(--sans);font-size:12px;letter-spacing:.22em;color:var(--ink3);margin-bottom:6px}
.bname{font-size:27px;letter-spacing:.16em;margin:0 0 2px;font-weight:700}
.bsub{font-size:12.5px;color:var(--ink2);line-height:1.7;margin-bottom:18px}
.searchbox{position:relative;margin:14px 0 18px}
#q{width:100%;padding:9px 11px;border:1px solid var(--line);background:#fff;border-radius:2px;
  font-family:var(--sans);font-size:13px;color:var(--ink);outline:none}
#q:focus{border-color:var(--blue);box-shadow:0 0 0 3px var(--blue-l)}
.results{position:absolute;left:0;right:0;top:41px;background:#fff;border:1px solid var(--line);
  max-height:280px;overflow:auto;display:none;z-index:40;box-shadow:0 12px 30px rgba(40,44,48,.10)}
.results.on{display:block}
.r{display:block;padding:8px 11px;border-bottom:1px solid #f1ece2;cursor:pointer;text-decoration:none;color:var(--ink)}
.r:hover,.r.act{background:var(--blue-l)}
.r b{font-weight:700;font-family:var(--sans);font-size:13.5px}
.r span{display:block;font-family:var(--sans);font-size:11.5px;color:var(--ink3);margin-top:2px;line-height:1.5}
.navitem{display:flex;align-items:center;gap:9px;padding:7px 9px;text-decoration:none;color:var(--ink2);
  font-family:var(--sans);font-size:13.5px;border-radius:2px;line-height:1.5}
.navitem:hover{background:#ece6d9;color:var(--ink)}
.navitem.on{background:#fff;color:var(--ink);box-shadow:inset 2px 0 0 var(--copper)}
.navitem .dot{width:4px;height:4px;border-radius:50%;background:var(--ink3);flex:0 0 4px}
.navitem.on .dot{background:var(--copper)}
.meta{margin-top:22px;padding-top:14px;border-top:1px solid var(--line);font-family:var(--sans);
  font-size:11.5px;color:var(--ink3);line-height:1.9}
main{flex:1;min-width:0;padding:0 0 90px}
.inner{max-width:41rem;margin:0 auto;padding:0 30px}
.panel{display:none;animation:fade .3s ease}
.panel.on{display:block}
@keyframes fade{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:none}}
h1{font-size:30px;letter-spacing:.06em;line-height:1.5;margin:56px 0 6px;font-weight:700}
h2{font-size:19px;letter-spacing:.04em;margin:44px 0 14px;font-weight:700;color:var(--ink);
  padding-left:12px;border-left:3px solid var(--copper);line-height:1.6}
h3{font-size:16px;margin:30px 0 8px;font-weight:700;color:var(--ink2)}
p{margin:0 0 1.05em;text-align:justify}
blockquote{margin:20px 0;padding:14px 18px;background:#fff;border-left:2px solid var(--copper);
  font-family:var(--sans);font-size:13.5px;line-height:1.9;color:var(--ink2)}
code{font-family:ui-monospace,Menlo,Consolas,monospace;font-size:.86em;background:#eee8dc;
  padding:1px 5px;border-radius:2px;color:#5a4632}
hr.rule{border:0;border-top:1px solid var(--line);margin:34px 0}
ul,ol{margin:0 0 1.1em;padding-left:1.5em}
li{margin:.28em 0}
.tbl{margin:18px 0 24px;overflow-x:auto;border:1px solid var(--line);background:#fff}
table{border-collapse:collapse;width:100%;font-family:var(--sans);font-size:13px;line-height:1.78}
th,td{padding:9px 11px;border-bottom:1px solid #f0ebe0;text-align:left;vertical-align:top}
th{background:var(--paper2);font-weight:700;color:var(--ink);white-space:nowrap;border-bottom:1px solid var(--line)}
tbody tr:hover{background:#fcfaf5}
.chapter{max-width:36rem;margin:0 auto}
.chtitle{border-bottom:1px solid var(--line);padding-bottom:14px;margin-bottom:28px}
.chapter p{font-size:17.5px;line-height:2.05;text-indent:0}
.chapter p.dlg{margin-bottom:.42em}
.chapter p.dlg + p.dlg{margin-top:0}
.pager{max-width:36rem;margin:44px auto 0;display:flex;justify-content:space-between;gap:12px}
.pg{font-family:var(--sans);font-size:13px;padding:9px 16px;background:#fff;border:1px solid var(--line);
  color:var(--ink2);cursor:pointer;border-radius:2px}
.pg:hover{border-color:var(--blue);color:var(--ink)}
/* 封面 */
.coverbox{padding:46px 0 10px}
.cover{width:100%;max-width:360px;display:block;margin:0 auto;box-shadow:0 18px 44px rgba(40,44,48,.16);border-radius:1px}
.csscover{display:none;max-width:360px;margin:0 auto;aspect-ratio:2/3;background:linear-gradient(#788b96,#e4d4ba 72%);
  position:relative;overflow:hidden;box-shadow:0 18px 44px rgba(40,44,48,.16)}
.csscover .t{position:absolute;top:9%;left:0;right:0;text-align:center;font-size:40px;letter-spacing:.2em;
  color:#28323a;font-weight:700}
.csscover .s{position:absolute;top:20%;left:0;right:0;text-align:center;font-size:12.5px;color:#3c464e;font-family:var(--sans)}
.csscover .pend{position:absolute;left:50%;top:30%;width:2px;height:16%;background:#585046;transform:translateX(-50%)}
.csscover .bob{position:absolute;left:50%;top:46%;width:34px;height:34px;border-radius:50%;
  background:radial-gradient(circle at 40% 35%,#cbb083,#a6804c);transform:translate(-50%,-50%)}
.csscover .paper{position:absolute;left:8%;right:8%;top:50%;bottom:6%;background:#f1e8d5;
  box-shadow:inset 0 0 0 1px #e0d3ba;clip-path:polygon(1% 2%,99% 1%,100% 99%,0 98%)}
.csscover .shade{position:absolute;left:46%;top:46%;width:26%;height:52%;background:rgba(60,54,46,.16);transform:rotate(14deg)}
.ctitle{text-align:center;margin-top:34px;font-size:34px;letter-spacing:.18em}
.clead{text-align:center;font-family:var(--sans);font-size:13.5px;color:var(--ink2);margin-top:2px}
.facts{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;max-width:560px;margin:34px auto 0}
.fact{background:#fff;border:1px solid var(--line);padding:12px 10px;text-align:center}
.fact b{display:block;font-family:var(--sans);font-size:19px;color:var(--copper);letter-spacing:.02em}
.fact span{font-family:var(--sans);font-size:11px;color:var(--ink3)}
.tag{display:inline-block;font-family:var(--sans);font-size:11px;padding:1px 7px;border-radius:2px;background:#ece6d9;color:#5a5040;white-space:nowrap}
.tag-人物{background:#e6ecef;color:#3d5360}.tag-地点{background:#e9eee6;color:#4a5c43}
.tag-道具{background:#f0e8dd;color:#6b5136}.tag-术语{background:#ece9f0;color:#4f4460}
.idxtable th:nth-child(1),.idxtable td:nth-child(1){width:82px}
.idxtable th:nth-child(2),.idxtable td:nth-child(2){width:58px}
.idxtable th:nth-child(3),.idxtable td:nth-child(3){width:64px}
.idxtable th:nth-child(5),.idxtable td:nth-child(5){width:150px}
.idxtable td.c-name{font-weight:700;font-family:var(--serif);font-size:13.5px}
.idxtable td.c-ch,.idxtable td.c-rel{color:var(--ink3);font-size:12px;white-space:nowrap}
tr.hit td{background:var(--hit);transition:background 1.2s}
.small{font-family:var(--sans);font-size:12.5px;color:var(--ink3)}
@media(max-width:900px){
  .wrap{display:block}
  aside{position:static;width:auto;height:auto;border-right:0;border-bottom:1px solid var(--line);padding:18px 16px}
  .bname{font-size:22px}
  .bsub,.meta{display:none}
  .cover{max-width:250px}
  .inner{padding:0 18px}
  h1{font-size:24px;margin-top:34px}
  .facts{grid-template-columns:repeat(2,1fr)}
  .chapter p{font-size:16.5px}
}
</style>
</head>
<body>
<div id="bar"></div>
<div class="wrap">
<aside>
  <div class="brand">课堂虚构作品 · AI 小说与 IP 设定集</div>
  <h1 class="bname">账本城</h1>
  <div class="bsub">三章短篇 · 世界观设定集 · 25 条索引<br>全书 3575 字，一次读完。</div>
  <div class="searchbox">
    <input id="q" type="text" autocomplete="off" placeholder="检索索引：输入名称 / 类别 / 释义">
    <div class="results" id="res"></div>
  </div>
  <nav>__NAV__</nav>
  <div class="meta">
    索引：人物 __C1__ · 地点 __C2__ · 道具 __C3__ · 术语 __C4__<br>
    校对：8 处问题已修订 / 7 项通过<br>
    本页零外部依赖，可离线双击打开。
  </div>
</aside>
<main>
<div class="inner">

<section class="panel on" id="cover">
  <div class="coverbox">
    <img class="cover" id="coverimg" src="10_封面.png" alt="《账本城》封面：摊开的旧账册、静止的钟摆与斜长阴影">
    <div class="csscover" id="csscover">
      <div class="t">账本城</div>
      <div class="s">一部关于条目、划掉与钟声的三章短篇</div>
      <div class="pend"></div><div class="bob"></div>
      <div class="paper"></div><div class="shade"></div>
    </div>
    <div class="ctitle">账本城</div>
    <div class="clead">一部关于条目、划掉与钟声的三章短篇</div>
    <div class="facts">
      <div class="fact"><b>3</b><span>章 正 文</span></div>
      <div class="fact"><b>3575</b><span>字 · 汉字</span></div>
      <div class="fact"><b>5</b><span>条 硬 设 定</span></div>
      <div class="fact"><b>25</b><span>条 索 引</span></div>
    </div>
  </div>
  <h2>这本书讲什么</h2>
  <p>账本城不用钱，只用「条目」：每写下一条，就必须划掉另一条。东街的记录员沈砚每天给公共账册换页，某天他发现昨日最后一格本该有条目，纸面却是空的。他袖口里那半片撕角旧纸，只剩半个「木」字。</p>
  <p>一个只会抄写的人、一个从不摘手套的守钟人、一个只在周五傍晚出现的学徒，被同一页纸牵到一起。这一周周五傍晚，旧钟楼的钟响了一次——城里只有一个人做了不可撤回的选择。</p>
  <h2>怎么读</h2>
  <ul>
    <li>左侧目录切换章节；每章末尾有「本章状态登记」（人物位置、随身道具、时间点）。</li>
    <li>顶部检索框可查 25 条索引，回车即跳到附录对应条目并高亮。</li>
    <li>另有《世界观设定集》《连续性校对表》《IP 商业化与销售》《制作说明》四个附录页。</li>
  </ul>
</section>

__CH__

<section class="panel" id="setting">
  <div class="chapter">
__SETTING__
  </div>
</section>

<section class="panel" id="appendix">
  <div class="chapter">
    <h1 class="chtitle">设定附录 · 索引</h1>
    <p class="small">下列 __TOTAL__ 条全部由正文抽取，脚本核对：JSON 可解析、related 全部命中。与《世界观设定集》有出入时，以设定集为准。</p>
__APPENDIX__
    <h2>使用说明</h2>
    <p>索引不是装饰。它让「二刷」有落点：任何一个人名、地点、物件、术语，都能回到它第一次出现的章节；关联条目给出同一场景里互相牵连的其它名字。</p>
  </div>
</section>

<section class="panel" id="audit">
  <div class="chapter">
    <h1 class="chtitle">连续性校对表</h1>
    <p class="small">按六类检查项（人物 / 时间 / 道具 / 地点 / 术语 / 硬设定）逐条核验三章正文，共 15 行记录：8 处问题全部修订，7 项通过。</p>
__AUDIT__
  </div>
</section>

<section class="panel" id="sales">
  <div class="chapter">
    <h1 class="chtitle">IP 商业化与销售方案</h1>
    <p class="small">课堂推演：价格、转化率与收入均为假设值，不代表真实成交，也不得对外宣称。</p>
__SALES__
  </div>
</section>

<section class="panel" id="notes">
  <div class="chapter">
    <h1 class="chtitle">制作说明</h1>
__NOTES__
  </div>
</section>

</div>
</main>
</div>
<script>
var IDX = __IDX__;
var panelIds = ['cover','ch1','ch2','ch3','setting','appendix','audit','sales','notes'];
function show(id, scroll){
  panelIds.forEach(function(p){
    var el = document.getElementById(p);
    if(el) el.classList.toggle('on', p === id);
  });
  document.querySelectorAll('.navitem').forEach(function(a){
    a.classList.toggle('on', a.getAttribute('data-t') === id);
  });
  if(scroll !== false) window.scrollTo({top:0, behavior:'auto'});
  history.replaceState(null,'','#'+id);
}
document.querySelectorAll('.navitem').forEach(function(a){
  a.addEventListener('click', function(e){ e.preventDefault(); show(a.getAttribute('data-t')); });
});
document.querySelectorAll('.pg').forEach(function(b){
  b.addEventListener('click', function(){ show(b.getAttribute('data-go')); });
});
var q = document.getElementById('q'), res = document.getElementById('res'), act = -1, cur = [];
function esc(s){ return s.replace(/[&<>]/g, function(c){ return {'&':'&amp;','<':'&lt;','>':'&gt;'}[c]; }); }
function render(kw){
  kw = (kw||'').trim().toLowerCase();
  if(!kw){ res.classList.remove('on'); res.innerHTML=''; cur=[]; return; }
  cur = IDX.filter(function(it){
    return it.name.toLowerCase().indexOf(kw) >= 0 || it.gloss.toLowerCase().indexOf(kw) >= 0 || it.category.indexOf(kw) >= 0;
  }).slice(0,12);
  if(!cur.length){ res.innerHTML = '<div class="r"><b>没有匹配条目</b><span>试试「银」「钟」「条目」</span></div>'; res.classList.add('on'); return; }
  res.innerHTML = cur.map(function(it,i){
    return '<a class="r" data-i="'+i+'"><b>'+esc(it.name)+'</b><span>'+it.category+' · 第'+it.first_chapter+'章 · '+esc(it.gloss)+'</span></a>';
  }).join('');
  res.classList.add('on'); act = -1;
}
function gotoItem(i){
  var it = cur[i]; if(!it) return;
  show('appendix', false);
  var row = document.getElementById('idx-'+it.n);
  if(row){
    row.scrollIntoView({block:'center'});
    row.classList.remove('hit');
    void row.offsetWidth;
    row.classList.add('hit');
    setTimeout(function(){ row.classList.remove('hit'); }, 2600);
  }
  res.classList.remove('on');
}
q.addEventListener('input', function(){ render(q.value); });
q.addEventListener('keydown', function(e){
  var items = res.querySelectorAll('.r[data-i]');
  if(e.key === 'ArrowDown' || e.key === 'ArrowUp'){
    e.preventDefault();
    if(!items.length) return;
    act = e.key === 'ArrowDown' ? (act+1) % items.length : (act-1+items.length) % items.length;
    items.forEach(function(el,i){ el.classList.toggle('act', i === act); });
  } else if(e.key === 'Enter'){
    e.preventDefault();
    gotoItem(act < 0 ? 0 : act);
  } else if(e.key === 'Escape'){ res.classList.remove('on'); }
});
res.addEventListener('click', function(e){
  var a = e.target.closest('.r[data-i]'); if(!a) return;
  gotoItem(parseInt(a.getAttribute('data-i'),10));
});
document.addEventListener('click', function(e){
  if(!e.target.closest('.searchbox')) res.classList.remove('on');
});
var img = document.getElementById('coverimg'), css = document.getElementById('csscover');
function fallback(){ img.style.display='none'; css.style.display='block'; }
img.addEventListener('error', fallback);
if(img.complete && img.naturalWidth === 0) fallback();
document.addEventListener('scroll', function(){
  var h = document.documentElement;
  var p = h.scrollTop / Math.max(1, (h.scrollHeight - h.clientHeight));
  document.getElementById('bar').style.width = (p*100).toFixed(2) + '%';
}, {passive:true});
var start = (location.hash || '').replace('#','');
if(start && panelIds.indexOf(start) >= 0) show(start); else show('cover');
</script>
</body>
</html>
"""

page = (page.replace('__NAV__', nav_html)
            .replace('__CH__', CH)
            .replace('__SETTING__', setting_html)
            .replace('__APPENDIX__', appendix_table)
            .replace('__AUDIT__', audit_html)
            .replace('__SALES__', sales_html)
            .replace('__NOTES__', notes_html)
            .replace('__TOTAL__', str(len(idx)))
            .replace('__C1__', str(counts['人物'])).replace('__C2__', str(counts['地点']))
            .replace('__C3__', str(counts['道具'])).replace('__C4__', str(counts['术语'])))

# 索引注入（带 n 字段，供跳转定位）
idx_js = [{ 'n': n, 'name': it['name'], 'category': it['category'], 'first_chapter': it['first_chapter'],
            'gloss': it['gloss'] } for n, it in enumerate(idx)]
page = page.replace('__IDX__', json.dumps(idx_js, ensure_ascii=False))

with open(os.path.join(BASE, '11_阅读版.html'), 'w', encoding='utf-8') as f:
    f.write(page)
print('写出 11_阅读版.html，大小 %.1f KB，章节 %d，索引 %d' % (len(page.encode('utf-8'))/1024, len(chapters), len(idx)))
